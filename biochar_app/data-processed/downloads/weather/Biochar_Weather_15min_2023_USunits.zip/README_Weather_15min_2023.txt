Biochar Fruita CSU Experiment - 15-min Weather Data (2023)

Source:
  - Direct CoAgMet-style download URL: https://coagmet.colostate.edu/data/5min/frt03.csv?header=yes&fields=t,rh,dewpt,vp,solarRad,precip,windSpeed,windDir,st5cm,st15cm&from=2023-01-01T00:00&to=2023-12-31T23:59&tz=co&units=us&dateFmt=iso
  - CoAgMet builder page (construct custom URLs): https://coagmet.colostate.edu/data/url-builder

Files in this ZIP
-----------------
  - weather_15min_2023_USunits.csv : 15-minute time series for the full year
    (or up to the ETL run date).

Column naming convention
------------------------
  timestamp              : local time (America/Denver), 15-min step
  temp_air_degF          : air temperature
  rh_pct                 : relative humidity (%)
  dewpoint_degF          : dewpoint temperature
  vp_kPa                 : vapor pressure (kPa)
  solarRad_Wm2           : solar radiation (W/m²)
  precip_in              : precipitation increments (inches per 15-min bin)
  windSpeed_mph          : wind speed (mph)
  windDir_deg            : wind direction (degrees)
  soil_temp_2in_degF     : 2-inch soil temperature (°F)
  soil_temp_6in_degF     : 6-inch soil temperature (°F)

Notes:
  - Timestamps are naive datetimes interpreted as America/Denver local time.
  - Units are US customary (e.g., precip_in, temp_air_degF); you may also see
    derived metric columns (precip_mm, temp_air_degC) where present.
  - Precipitation values have been cleaned so that negatives are clipped to 0
    and typical CoAgMet missing-value codes (e.g., -999) are treated as NaN.