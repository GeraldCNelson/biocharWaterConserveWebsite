Biochar Fruita CSU Experiment - 15-min Weather Data (2024)

Source:
  - Direct CoAgMet-style download URL: https://coagmet.colostate.edu/data/5min/frt03.csv?header=yes&fields=t,rh,dewpt,vp,solarRad,precip,windSpeed,windDir,st5cm,st15cm&from=2024-01-01T00:00&to=2024-12-31T23:59&tz=co&units=us&dateFmt=iso
  - CoAgMet builder page (construct custom URLs): https://coagmet.colostate.edu/data/url-builder

Notes:
  - Timestamps are naive datetimes interpreted as America/Denver local time.
  - Units are US customary (e.g., precip_in, temp_air_degF) with derived
    metric columns (precip_mm, temp_air_degC) where present.
  - Values may have been cleaned (e.g., -999 → 0 for precip, negatives clipped).